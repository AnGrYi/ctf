from flask import Flask, render_template, request, g
import sqlite3

app = Flask(__name__)

# Function to get the database connection
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect('database.db')
    return db

# Function to close the database connection
@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

# Initialize database
def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

# Check if database is initialized before each request
@app.before_request
def before_request():
    init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Construct SQL query with concatenated user input (vulnerable to SQL injection)
        query = "SELECT * FROM users WHERE username='" + username + "' AND password='" + password + "' AND admin=0"
        cur = get_db().cursor()
        cur.execute(query)
        user = cur.fetchone()
        if user:
            return render_template('user.html', username=username)
        else:
            return "Invalid username or password."
    elif request.method == 'GET':
        return render_template('login.html')


@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Construct SQL query with concatenated user input (vulnerable to SQL injection)
        query = "SELECT * FROM users WHERE username='" + username + "' AND password='" + password + "' AND admin=1"
        cur = get_db().cursor()
        cur.execute(query)
        user = cur.fetchone()
        if user:
            return render_template('admin.html', flag="Inj3cTed{EncRypt3d_k0ch!-2K24}")
        else:
            return "Invalid admin username or password."
    elif request.method == 'GET':
        return render_template('admin_login.html')


if __name__ == '__main__':
    app.run(debug=True)
