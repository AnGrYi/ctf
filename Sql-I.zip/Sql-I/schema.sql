CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT,
    password TEXT,
    admin INTEGER
);
INSERT OR IGNORE INTO users (username, password, admin) VALUES ('admin', 'adminpasswordAngry', 1);
